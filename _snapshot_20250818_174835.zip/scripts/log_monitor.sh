#!/usr/bin/env bash
set -euo pipefail
echo "[log_monitor] done."
