print("[DUMMY] ZTOW runner: 監視1サイクル実行（ダミー）")
