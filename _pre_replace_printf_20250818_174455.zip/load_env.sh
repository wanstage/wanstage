export $(grep -v "^#" ~/WANSTAGE/.env | xargs)
